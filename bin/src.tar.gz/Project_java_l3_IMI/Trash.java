package Project_java_l3_IMI;

public class Trash {
static int trash=2;
}
