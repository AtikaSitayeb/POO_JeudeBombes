package Project_java_l3_IMI;

public class Wall {
	static int wall=3;

}
