package Project_java_l3_IMI;

import java.io.BufferedReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Graphe {
	Noeud [][] graphe;
	
	public Noeud[][] getGraphe() {
		return graphe;
	}
	public Graphe()  {
		
		ArrayList<String> level;
		try {
			level = levels();
		
		this.graphe=new Noeud[level.size()][level.get(0).length()];
		for(int i=0;i<level.size();i++)
			for(int j=0;j<level.get(0).length();j++) {
				this.graphe[i][j]=new Noeud(level.get(i).charAt(j), i, j);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}}
	
	public ArrayList<Noeud>	Shortest_path2(Noeud n1,Noeud n2) throws Exception{
		Noeud v;
		
				n1.path.add(n1);
				
			    	   if( n1.nom!='W' && 
			        				 n1.nom!='T' && 
			        				   n1.nom!='G') {
			    				    	  
			    	      if( n1.equals(n2)) {
			    	    	  constituerChemin(n1);
			        	      return n1.path;  
			           }
			          
			           for(int i=0;i<3 ;i++)
			        	   for(int j=0;j<3 ;j++) {
			        		   if( n1.x-1+i>0 && n1.y-1+j>0 &&
			        				   n1.x-1+i<this.graphe.length && n1.y-1+j<this.graphe[0].length 
			        				   &&  this.graphe[n1.x-1+i][n1.y-1+j].nom!='W' && 
			        				   this.graphe[n1.x-1+i][n1.y-1+j].nom!='T' && 
			        				   this.graphe[n1.x-1+i][n1.y-1+j].nom!='G'){
			        			  			        		  
			        		  v=this.graphe[n1.x-1+i][n1.y-1+j];
			        		   if(v.cout==0 ||  v.cout>n1.cout+1) {
			        			    v.cout = n1.cout +1; 
			        			    v.path.clear();
				                    v.path.addAll(n1.path) ;
				                   // v.path.add(n1);
				                    
				                    return Shortest_path2(v, n2);
				                   
			        		   }}
			        		   n1.heuristique =n1.cout + Math.abs(n1.x-n2.x)+ Math.abs(n1.y-n2.y);	
			        		   
			        
			        		    }}
			   	
				System.err.println ("pas de chemin"); return null;
				
			       
	}
	
	
	public void	Shortest_path(Noeud n1,Noeud n2) throws Exception{
		if(n1==null) {n2.path.add(n2);return;}
		Noeud u;
		Noeud v;
		ArrayList<Noeud> closedList = new ArrayList<Noeud>();
				ArrayList<Noeud> openList = new ArrayList<Noeud>();
				n1.path.clear();
				n1.heuristique= Math.abs(n1.x-n2.x)+ Math.abs(n1.y-n2.y);
				openList.add(n1);
			
				while(openList.iterator().hasNext() ) {
			    	   
			    	   if( openList.iterator().next().nom!='W' && 
			        				   openList.iterator().next().nom!='T' && 
			        				   openList.iterator().next().nom!='G') {
			    		   
			    		   //openList.sort((s1,s2)->(s1.cout-s2.cout));
			    		   openList.sort((s1,s2)->(s1.heuristique-s2.heuristique));
			    		  // openList.subList(fromIndex, toIndex)
			    		 // u= min(openList);
			    		  u=openList.iterator().next();
			    		   openList.remove(0);
			    	  
			    	      if( u.equals(n2)) {
			        	   
				           n2.path=u.path;
				           n2.path.add(n2);
				           constituerChemin(u);
				           
			          
			           return;  
			           }
			          
			           for(int i=0;i<3 ;i++)
			        	   for(int j=0;j<3 ;j++) {
			        		   if( u.x-1+i>0 && u.y-1+j>0 &&
			        				   u.x-1+i<this.graphe.length && u.y-1+j<this.graphe[0].length 
			        				   &&  this.graphe[u.x-1+i][u.y-1+j].nom!='W' && 
			        				   this.graphe[u.x-1+i][u.y-1+j].nom!='T' && 
			        				   this.graphe[u.x-1+i][u.y-1+j].nom!='G'){
			        			  			        		  
			        		   v=this.graphe[u.x-1+i][u.y-1+j];
			        		   if((!openList.contains(v) && !closedList.contains(v)) || (openList.contains(v)&& v.cout>u.cout+1)) {
			        			    v.cout = u.cout +1; 
			        			    v.path.clear();
				                    v.path.addAll(u.path) ;
				                    v.path.add(u);
				                    v.heuristique =v.cout + Math.abs(v.x-n2.x)+ Math.abs(v.y-n2.y);
				                   openList.add(v); 
				                   
			        		   }}
			        		  
			           closedList.add(u);
			           }}
			    	   }
				System.err.println ("pas de chemin");
				throw new Exception();
			       
	}
	private Noeud min(ArrayList<Noeud> openList) {
		int i=0;List<Noeud> openList2; Noeud j=openList.get(0);
		System.out.println("aaaaaaaaaaa"+openList);
		
		 openList.sort((s1,s2)->(s1.heuristique-s2.heuristique));
		 
		
		 
	
		 for (Noeud noeud : openList) {
			if(openList.get(0).cout==noeud.cout)i++;
		}
		
		 if(i>1) {
			 System.out.println(i+"ii111"+openList);
			 
		 openList2=openList.subList(0,i-1);
		 System.out.println("2222"+openList2);
		 openList2.sort((s1,s2)->(s1.cout-s2.cout));
		 //openList.remove(openList2.get(0));
		 System.out.println("111"+openList);
		 System.out.println("2222"+openList2);
		j=openList2.get(0);
		openList2.remove(0);
		//openList.remove(openList2.get(0));
		 //openList.addAll(openList2);
		 return j;
		 }
		 j=openList.get(0);
		 openList.remove(0);
		 System.out.println("mmm"+openList);
		 return j;
	}
	private void constituerChemin(Noeud u2) {
		
		for (Noeud noeuds : u2.path) {
			noeuds.nom='P';
		}
		
		
	}
	@Override
	public String toString() {
		
		String s="\n";
		for (Noeud[] noeuds : this.graphe) {
			for (Noeud noeud : noeuds) {
				s+=noeud.nom;
			}s+="\n";
			
		}
		System.out.println(this.graphe.length+","+this.graphe[0].length);
		return s;
	}
	public static ArrayList<String> levels() throws Exception  {
		
		ArrayList<String> level=new ArrayList<String>();
		
		Path path = Paths.get(System.getProperty("user.dir"),"Levels","level1.txt");
	     try 
			(BufferedReader reader = Files.newBufferedReader(path)) {
			  
			  Matcher m;
			  Pattern pcorpus=Pattern.compile(".*(^[W,T].*[W,T]$)");
			  String line=reader.readLine();
			  int sez=line.length();
				
			while 
			(line  != null) { 
				m=pcorpus.matcher(line);
				if(m.matches() && sez==line.length())
				{	 level.add(m.group(1));
					
				}else throw new Exception("fichier incorecte");  	 
			line=reader.readLine();}
			reader.close();
			System.out.println(level);
			 
			  Pattern pcorpus2=Pattern.compile("[W,T]+");
			  m=pcorpus2.matcher(level.get(0));
			if(!((m=pcorpus2.matcher(level.get(level.size()-1))).matches()&&
					(m=pcorpus2.matcher(level.get(0))).matches()))throw new Exception("fichier incorecte");
	     			
		}
	     			
	     		
	
		return level;
		

	}
	public int  getWidth() {return this.graphe.length;} 
	public int getHeight() {return this.graphe[0].length;}
	public Noeud getNoeud(int i,int j ){return this.graphe[i][j];}	
	
}
