package Project_java_l3_IMI;

public class Garbage {
	static int garbage=1; 

}
