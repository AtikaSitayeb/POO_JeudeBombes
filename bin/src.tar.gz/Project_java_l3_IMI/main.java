package Project_java_l3_IMI;

public class main {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Graphe g=new Graphe();
		Noeud n1=new Noeud(' ',6,40 );
		Noeud n2=new Noeud(' ', 7,16);
		
//g.Shortest_path2(n1,n2);

System.out.println("gg:"+g+"gdhsj"+g.Shortest_path2(n1,n2));
	}

}
